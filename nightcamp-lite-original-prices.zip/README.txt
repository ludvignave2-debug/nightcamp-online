NIGHTCAMP Lite price fix
Replace ONLY the root cases.json with this cases.json.
Do not replace public/index.html or server.js.
