NIGHTCAMP MULTIPLAYER DEMO
==========================

This version uses a small Node.js + Socket.IO server so real people can join the same battle.
Virtual Scrap only; no real-money deposits or withdrawals.

RUN LOCALLY
1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run: npm install
4. Run: npm start
5. Open: http://localhost:3000

JOIN FROM ANOTHER DEVICE ON THE SAME NETWORK
- Open the server computer's local IP address with port 3000, for example:
  http://192.168.x.x:3000
- Firewall/router rules may need to allow port 3000.

JOIN OVER THE INTERNET
- Deploy this whole folder to any Node.js hosting service.
- Start command: npm start
- The service must support WebSockets.
- Share the public HTTPS URL.

HOW ROOMS WORK
- Open Crate Battles.
- Enter a player name.
- Host chooses battle type/rule/cases and clicks CREATE ONLINE BATTLE.
- Share the 6-character room code.
- Other players enter their name + code and click JOIN BATTLE.
- Non-host players READY UP.
- Host clicks START ONLINE BATTLE after all required slots are filled.
- The server sends one shared random seed so all connected players see the same drops and same Jackpot draw.

NOTES
- Room state and battle synchronization are server-backed.
- Demo Scrap balance is still local to each browser; this is not an account/payment backend.
