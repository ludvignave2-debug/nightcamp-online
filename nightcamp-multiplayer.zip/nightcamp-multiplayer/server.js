const path = require('path');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'public')));

const rooms = new Map();
const formats = {
  '1v1': 2,
  '2v2': 4,
  '3v3': 6,
  '1v1v1': 3,
  '1v1v1v1': 4
};

function cleanName(name) {
  const v = String(name || 'Player').trim().slice(0, 20);
  return v || 'Player';
}
function roomCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out = '';
  do {
    out = Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  } while (rooms.has(out));
  return out;
}
function publicRoom(room) {
  return {
    code: room.code,
    hostId: room.hostId,
    phase: room.phase,
    settings: room.settings,
    cases: room.cases,
    players: room.players.map((p, i) => ({ id: p.id, name: p.name, ready: p.ready, seat: i }))
  };
}
function broadcast(room) {
  io.to(room.code).emit('room:update', publicRoom(room));
}
function getRoomForSocket(socket) {
  for (const room of rooms.values()) {
    if (room.players.some(p => p.id === socket.id)) return room;
  }
  return null;
}
function leaveCurrent(socket) {
  const room = getRoomForSocket(socket);
  if (!room) return;
  room.players = room.players.filter(p => p.id !== socket.id);
  socket.leave(room.code);
  if (!room.players.length) {
    rooms.delete(room.code);
    return;
  }
  if (room.hostId === socket.id) room.hostId = room.players[0].id;
  if (room.phase !== 'battle') room.phase = 'lobby';
  broadcast(room);
}

io.on('connection', socket => {
  socket.on('room:create', (payload = {}, ack = () => {}) => {
    leaveCurrent(socket);
    const code = roomCode();
    const settings = payload.settings || { format: '1v1', rule: 'normal' };
    const room = {
      code,
      hostId: socket.id,
      phase: 'lobby',
      settings: {
        format: formats[settings.format] ? settings.format : '1v1',
        rule: String(settings.rule || 'normal')
      },
      cases: Array.isArray(payload.cases) ? payload.cases.slice(0, 10) : [],
      players: [{ id: socket.id, name: cleanName(payload.name), ready: true }]
    };
    rooms.set(code, room);
    socket.join(code);
    ack({ ok: true, room: publicRoom(room) });
    broadcast(room);
  });

  socket.on('room:join', (payload = {}, ack = () => {}) => {
    leaveCurrent(socket);
    const code = String(payload.code || '').trim().toUpperCase();
    const room = rooms.get(code);
    if (!room) return ack({ ok: false, error: 'Room not found.' });
    if (room.phase === 'battle') return ack({ ok: false, error: 'Battle already started.' });
    const capacity = formats[room.settings.format] || 2;
    if (room.players.length >= capacity) return ack({ ok: false, error: 'Battle is full.' });
    room.players.push({ id: socket.id, name: cleanName(payload.name), ready: false });
    socket.join(code);
    ack({ ok: true, room: publicRoom(room) });
    broadcast(room);
  });

  socket.on('room:leave', () => leaveCurrent(socket));

  socket.on('room:ready', (ready) => {
    const room = getRoomForSocket(socket);
    if (!room) return;
    const p = room.players.find(x => x.id === socket.id);
    if (!p) return;
    p.ready = !!ready;
    if (socket.id === room.hostId) p.ready = true;
    broadcast(room);
  });

  socket.on('room:settings', (payload = {}) => {
    const room = getRoomForSocket(socket);
    if (!room || room.hostId !== socket.id || room.phase !== 'lobby') return;
    if (payload.settings) {
      if (formats[payload.settings.format]) room.settings.format = payload.settings.format;
      if (payload.settings.rule) room.settings.rule = String(payload.settings.rule);
    }
    if (Array.isArray(payload.cases)) room.cases = payload.cases.slice(0, 10);
    const capacity = formats[room.settings.format] || 2;
    if (room.players.length > capacity) room.players = room.players.slice(0, capacity);
    broadcast(room);
  });

  socket.on('battle:start', (ack = () => {}) => {
    const room = getRoomForSocket(socket);
    if (!room) return ack({ ok: false, error: 'No room.' });
    if (room.hostId !== socket.id) return ack({ ok: false, error: 'Only the host can start.' });
    const capacity = formats[room.settings.format] || 2;
    if (room.players.length !== capacity) return ack({ ok: false, error: `Need ${capacity} players.` });
    if (!room.cases.length) return ack({ ok: false, error: 'Choose at least one case.' });
    if (room.players.some(p => !p.ready)) return ack({ ok: false, error: 'Everyone must be ready.' });
    room.phase = 'battle';
    const seed = Math.floor(Math.random() * 0xFFFFFFFF) >>> 0;
    const payload = { room: publicRoom(room), seed };
    io.to(room.code).emit('battle:go', payload);
    ack({ ok: true });
  });

  socket.on('battle:returnLobby', () => {
    const room = getRoomForSocket(socket);
    if (!room || room.hostId !== socket.id) return;
    room.phase = 'lobby';
    room.players.forEach(p => { p.ready = p.id === room.hostId; });
    broadcast(room);
  });

  socket.on('disconnect', () => leaveCurrent(socket));
});

server.listen(PORT, () => console.log(`NIGHTCAMP multiplayer running on http://localhost:${PORT}`));
